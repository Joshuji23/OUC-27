// app.js
App({
  onLaunch: function() {
    // 初始化云开发环境
    if (wx.cloud) {
      wx.cloud.init({
        env: 'env-5gwno7u9931876ca', // 替换为您的云开发环境ID
        traceUser: true
      });
      
      // 保存云数据库引用到globalData
      this.globalData.db = wx.cloud.database();
    }
  },
  
  // 全局数据
  globalData: {
    db: null
  }
})
