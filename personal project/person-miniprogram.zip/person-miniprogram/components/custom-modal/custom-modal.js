// custom-modal.js
Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    title: {
      type: String,
      value: '确认操作'
    },
    content: {
      type: String,
      value: ''
    },
    confirmText: {
      type: String,
      value: '确认'
    },
    cancelText: {
      type: String,
      value: '取消'
    }
  },
  methods: {
    onCancel: function() {
      this.triggerEvent('cancel');
    },
    onConfirm: function() {
      this.triggerEvent('confirm');
    },
    // 点击蒙层不关闭弹窗
    onMaskTap: function() {
      return;
    }
  }
})