Page({
    data: {},   

    goSingle() {
      wx.navigateTo({
        url: '/pages/story/story?mode=single',
        animationType: 'fade-in',
        animationDuration: 500
      });
    },
  
    goAdventure() {
      wx.navigateTo({
        url: '/pages/story/story?mode=adventure',
        animationType: 'fade-in',
        animationDuration: 500
      });
    },
    
    // 跳转到多人模式页面
  goMultiplayer() {
    wx.navigateTo({
      url: '/pages/multiplayer/multiplayer',
      animationType: 'fade-in',
      animationDuration: 500
    });
  },
  
  // 跳转到仓库页面
  goRepository() {
    wx.navigateTo({
      url: '/pages/repository/repository',
      animationType: 'fade-in',
      animationDuration: 500
    });
  }
});
  