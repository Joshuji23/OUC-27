Page({
  data: {
    userInfo: null,
    hasUserInfo: false,
    canIUseGetUserProfile: false
  },

  onLoad() {
    // 检查是否可以使用 getUserProfile API
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
    
    // 检查是否已经授权过
    wx.getStorage({ 
      key: 'userInfo',
      success: (res) => {
        this.setData({
          userInfo: res.data,
          hasUserInfo: true
        })
      }
    })
  },

  // 微信授权登录
  getUserProfile() {
    wx.getUserProfile({
      desc: '用于完善用户资料',
      success: (res) => {
        // 保存用户信息到本地存储
        wx.setStorage({
          key: 'userInfo',
          data: res.userInfo
        })
        
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
        
        wx.showToast({
          title: '故事开始',
          icon: 'success'
        });
        
        // 登录成功后跳转到首页
        setTimeout(() => {
          wx.navigateTo({
            url: '/pages/index/index'
          })
        }, 1500);
      },
      fail: () => {
        wx.showToast({
          title: '登录失败',
          icon: 'none'
        });
      }
    })
  }
});