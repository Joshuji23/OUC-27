Page({
  data: {
    // 故事内容列表
    storyContent: [],
    // 用户输入的新内容
    newContent: '',
    // 当前用户信息
    userInfo: null,
    // 故事ID（用于标识不同的多人故事）
    storyId: '',
    // 加载状态
    loading: false
  },

  onLoad(options) {
    // 从本地存储获取用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        userInfo: userInfo
      });
    }
    
    // 如果有故事ID参数，使用该ID；否则生成一个临时ID
    this.setData({
      storyId: options.storyId || 'temp_' + Date.now(),
      mode: options.mode || 'edit' // 设置模式，默认为编辑模式
    });
    
    // 获取云数据库引用
    this.db = wx.cloud.database();
    
    // 加载故事内容
    this.loadStoryContent();
  },
  
  // 加载故事内容
  loadStoryContent() {
    this.setData({ loading: true });
    
    // 从云数据库获取故事内容
    this.db.collection('story')
      .where({
        storyId: this.data.storyId
      })
      .orderBy('createTime', 'asc')
      .get()
      .then(res => {
        // 格式化数据以匹配原有的展示格式
        const formattedContent = res.data.map(item => ({
          id: item._id,
          content: item.content,
          user: {
            nickname: item.userInfo && item.userInfo.nickName ? item.userInfo.nickName : '',
            avatar: item.userInfo && item.userInfo.avatarUrl ? item.userInfo.avatarUrl : ''
          },
          time: item.createTime
        }));
        
        this.setData({
          storyContent: formattedContent,
          loading: false
        });
      })
      .catch(err => {
        console.error('加载故事内容失败', err);
        this.setData({ loading: false });
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      });
  },

  // 输入新内容
  inputNewContent(e) {
    this.setData({
      newContent: e.detail.value
    });
  },

  // 提交新内容到数据库
  submitContent() {
    const { newContent, userInfo } = this.data;
    
    if (!newContent.trim()) {
      wx.showToast({
        title: '内容不能为空',
        icon: 'none'
      });
      return;
    }
    
    if (!userInfo) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    this.setData({ loading: true });
    
    // 将故事内容添加到云数据库
    this.db.collection('story').add({
      data: {
        storyId: this.data.storyId,
        content: newContent.trim(),
        userInfo: {
          nickName: userInfo.nickName,
          avatarUrl: userInfo.avatarUrl
        },
        createTime: new Date().toLocaleString('zh-CN'),
        createTimeStamp: Date.now()
      }
    }).then(() => {
      // 重新加载故事内容
      this.loadStoryContent();
      
      this.setData({
        newContent: ''
      });
      
      wx.showToast({
        title: '书写成功',
        icon: 'success'
      });
    }).catch(err => {
      console.error('添加故事内容失败', err);
      this.setData({ loading: false });
      wx.showToast({
        title: '提交失败',
        icon: 'none'
      });
    });
  },

  // 刷新故事内容
  refreshContent() {
    this.loadStoryContent();
  },

  // 分享故事
  onShareAppMessage() {
    return {
      title: '来一起续写这个故事吧！',
      path: `/pages/multiplayer/multiplayer?storyId=${this.data.storyId}`,
      imageUrl: '/pages/image/background1.png'
    }
  }
});