Page({
  data: {
    stories: [],
    loading: false,
    showDeleteModal: false,
    currentDeleteStoryId: ''
  },

  onLoad: function() {
    // 获取云数据库引用
    this.db = wx.cloud.database();
    this.loadStories();
  },

  onShow: function() {
    // 每次显示页面时重新加载故事列表
    this.loadStories();
  },

  // 加载过往故事列表（从云数据库获取）
  loadStories: function() {
    this.setData({
      loading: true
    });

    // 从云数据库获取所有故事ID（去重）
    this.db.collection('story').aggregate()
      .group({
        _id: '$storyId',
        firstPiece: {
          $first: '$$ROOT'
        },
        length: {
          $sum: 1
        },
        firstCreateTime: {
          $min: '$createTime'
        }
      })
      .sort({
        firstCreateTime: -1
      })
      .limit(20)
      .end()
      .then(res => {
        // 格式化故事数据
        const formattedStories = res.list.map(item => ({
          id: item._id,
          title: item.firstPiece.content.substring(0, 20) + (item.firstPiece.content.length > 20 ? '...' : ''),
          creator: item.firstPiece.userInfo && item.firstPiece.userInfo.nickName ? 
                  item.firstPiece.userInfo.nickName : "{{}}",
          date: new Date(item.firstCreateTime).toLocaleDateString('zh-CN'),
          length: item.length
        }));

        this.setData({
          stories: formattedStories,
          loading: false
        });
      })
      .catch(err => {
        console.error('加载故事列表失败', err);
        this.setData({
          loading: false
        });
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      });
  },

  // 查看故事详情
  viewStory: function(e) {
    const storyId = e.currentTarget.dataset.id;
    const db = wx.cloud.database();
    
    // 先查询故事的原始模式
    db.collection('story')
      .where({
        storyId: storyId
      })
      .limit(1)
      .get()
      .then(res => {
        if (res.data && res.data.length > 0) {
          const storyData = res.data[0];
          // 根据故事的模式跳转到对应的页面
          if (storyData.mode === 'single' || storyData.mode === 'adventure') {
            // 单人模式或冒险模式，跳转到story页面
            wx.navigateTo({
              url: `/pages/story/story?mode=${storyData.mode}&storyId=${storyId}&edit=true`
            });
          } else {
            // 默认多人模式，跳转到multiplayer页面
            wx.navigateTo({
              url: `/pages/multiplayer/multiplayer?storyId=${storyId}&mode=edit`
            });
          }
        } else {
          // 如果没有找到故事，显示错误信息
          wx.showToast({
            title: '故事不存在',
            icon: 'none'
          });
        }
      })
      .catch(err => {
        console.error('查询故事模式失败', err);
        wx.showToast({
          title: '查询失败',
          icon: 'none'
        });
      });
  },

  // 刷新故事列表
  refreshStories: function() {
    this.loadStories();
  },

  // 显示删除确认弹窗
  deleteStory: function(e) {
    const storyId = e.currentTarget.dataset.id;
    this.setData({
      showDeleteModal: true,
      currentDeleteStoryId: storyId
    });
  },

  // 确认删除
  confirmDelete: function() {
    const storyId = this.data.currentDeleteStoryId;
    this.setData({
      showDeleteModal: false,
      loading: true
    });
    
    // 从云数据库删除所有具有该storyId的记录
    this.db.collection('story')
      .where({
        storyId: storyId
      })
      .remove()
      .then(() => {
        wx.showToast({
          title: '删除成功',
          icon: 'success'
        });
        // 重新加载故事列表
        this.loadStories();
      })
      .catch(err => {
        console.error('删除故事失败', err);
        this.setData({ loading: false });
        wx.showToast({
          title: '删除失败',
          icon: 'none'
        });
      });
  },

  // 取消删除
  cancelDelete: function() {
    this.setData({
      showDeleteModal: false,
      currentDeleteStoryId: ''
    });
  }
});