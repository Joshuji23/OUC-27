Page({
    data: {
        mode: "single",       // single / adventure
        story: "",            
        keywords: [],      
        options: [],   
        userInput: "",     
        storyGenerated: false,
        hasStoryStart: false,
        storyId: ""          // 故事唯一标识
    },
    
    onLoad(options) {
        this.setData({ 
            mode: options.mode || "single",
            storyId: options.storyId || ""
        });
        
        // 检查是否是编辑已有故事
        if (options.storyId && options.edit === 'true') {
            this.loadExistingStory();
        } else {
            // 开始新故事
            if (this.data.mode === "single") {
                this.startSingle();
            } else {
                this.startAdventure();
            }
        }
    },
    
    // 加载已有的故事内容
    loadExistingStory() {
        wx.showLoading({ title: "加载故事..." });
        
        const db = wx.cloud.database();
        
        // 查询最新的故事内容
        db.collection('story')
            .where({
                storyId: this.data.storyId
            })
            .orderBy('updateTime', 'desc')
            .limit(1)
            .get()
            .then(res => {
                wx.hideLoading();
                
                if (res.data && res.data.length > 0) {
                    const storyData = res.data[0];
                    this.setData({
                        story: storyData.content,
                        hasStoryStart: true,
                        storyGenerated: true
                    });
                    
                    // 如果是冒险模式，重新生成选项
                    if (this.data.mode === 'adventure') {
                        this.generateOptionsForAdventure();
                    }
                } else {
                    wx.showToast({ 
                        title: "故事加载失败", 
                        icon: "none" 
                    });
                    
                    // 如果加载失败，开始新故事
                    if (this.data.mode === "single") {
                        this.startSingle();
                    } else {
                        this.startAdventure();
                    }
                }
            })
            .catch(err => {
                wx.hideLoading();
                console.error('加载故事失败', err);
                wx.showToast({ 
                    title: "加载失败", 
                    icon: "none" 
                });
                
                // 如果加载失败，开始新故事
                if (this.data.mode === "single") {
                    this.startSingle();
                } else {
                    this.startAdventure();
                }
            });
    },
  
  // 为冒险模式生成新的选项
  generateOptionsForAdventure() {
    wx.showLoading({ title: "生成选项..." });
    
    this.callDeepSeek({
      model: "deepseek-chat",
      messages: [{
        role: "user",
        content: `当前故事：${this.data.story}\n\n请根据故事内容提供3个后续选择，每个选项独占一行，格式为"选项一：xxx"，"选项二：xxx"，"选项三：xxx"`
      }]
    }).then(res => {
      wx.hideLoading();
      
      if (res.choices && res.choices.length > 0) {
        // 只提取选项，不修改故事内容
        const text = res.choices[0].message.content || "";
        const lines = text.split("\n").map(l => l.trim()).filter(l => l.length > 0);
        let options = [];
        
        lines.forEach(line => {
          line = line.replace(/^[^\u4e00-\u9fa5]*/, ""); // 去掉行首非中文字符
          if (/^选项[一二三四五六七八九十]/.test(line)) {
            options.push(line.replace(/^选项[一二三四五六七八九十][:：]/, "").trim());
          }
        });
        
        this.setData({ options });
      } else {
        wx.showToast({ title: "选项生成失败", icon: "none" });
      }
    }).catch(err => {
      wx.hideLoading();
      console.error('生成选项失败', err);
      wx.showToast({ title: "选项生成失败", icon: "none" });
    });
  },
  
  // 页面卸载时触发，确保故事被保存
    onUnload() {
        // 保存故事到仓库
        if (this.data.story && this.data.story.length > 0) {
            this.saveStoryToRepository();
        }
    },

    goBack() {
        // 保存故事到仓库
        if (this.data.story && this.data.story.length > 0) {
            this.saveStoryToRepository();
        }
        wx.navigateTo({ url: '/pages/index/index' });
    },
    
    // 保存故事到云数据库仓库
    saveStoryToRepository() {
        // 直接获取云数据库引用
        const db = wx.cloud.database();
        
        // 检查数据库是否初始化
        if (!db) {
            console.error('数据库未初始化');
            return;
        }
        
        const storyCollection = db.collection('story');
        
        // 从故事内容中提取标题（前20个字符）
        const title = this.data.story.length > 20 ? 
                     this.data.story.substring(0, 20) + '...' : 
                     this.data.story;
        
        // 获取用户信息
        const userInfo = wx.getStorageSync('userInfo') || {
            nickName: '匿名用户',
            avatarUrl: ''
        };
        
        // 确保每个故事使用相同的storyId
        if (!this.data.storyId) {
            this.setData({
                storyId: new Date().getTime().toString()
            });
        }
        
        // 保存到云数据库
        storyCollection.add({
            data: {
                storyId: this.data.storyId, // 使用相同的storyId
                title: title,
                content: this.data.story,
                mode: this.data.mode,
                userInfo: userInfo,
                createTime: db.serverDate(),
                updateTime: db.serverDate(),
                length: this.data.story.length
            },
            success: (res) => {
                console.log('故事保存到仓库成功', res);
            },
            fail: (err) => {
                console.error('故事保存到仓库失败', err);
            }
        });
    },
      
    onInput(e) {
        this.setData({ userInput: e.detail.value });
    },
    
    // ----------续写 ---------------
    startSingle() {
        this.setData({
            story: "",
            hasStoryStart: false,
            storyGenerated: false
        });
    },

    userContinue() {
        if (!this.data.userInput) return wx.showToast({ title: "请输入内容", icon: "none" });
        
        // 如果是第一次输入，直接设置故事内容，否则追加
        const newStory = this.data.hasStoryStart ? 
            this.data.story + "\n" + this.data.userInput : 
            this.data.userInput;
        
        this.setData({
            story: newStory,
            userInput: "",
            hasStoryStart: true,
            storyGenerated: true
        }, () => {
            // 用户输入后，自动触发AI续写
            this.aiContinue();
        });
    },

    aiContinue() {
        wx.showLoading({ title: "文字浮现..." });
        return this.callDeepSeek({
            model: "deepseek-chat",
            messages: [{
                role: "user",
                content: `这是当前故事内容：${this.data.story}\n请AI续写一小段故事，大约50字。`
            }]
        }).then(res => {
            if (res.choices && res.choices.length > 0) {
                this.setData({ story: this.data.story + "\n" + (res.choices[0].message.content || "") });
            } else {
                wx.showToast({ title: "没有返回内容", icon: "none" });
            }
        }).catch(err => {
            console.error(err);
            wx.showToast({ title: "生成失败", icon: "none" });
        }).finally(() => {
            wx.hideLoading();
        });
    },

    getKeywords() {
        wx.showLoading({ title: "言海寻珠..." });
        return this.callDeepSeek({
            model: "deepseek-chat",
            messages: [{
                role: "user",
                content: `用户写了一个故事开头：${this.data.story}\n请生成3个有趣的关键词，简短（1-3字），写成三行，不允许产生其他文字。`
            }]
        }).then(res => {
            if (res.choices && res.choices.length > 0) {
                const text = res.choices[0].message.content || "";
                const keywords = text.split(/\n/).map(k => k.trim()).filter(k => k.length > 0);
                this.setData({ keywords });
            } else {
                wx.showToast({ title: "没有返回内容", icon: "none" });
            }
        }).catch(err => {
            console.error(err);
            wx.showToast({ title: "生成失败", icon: "none" });
        }).finally(() => {
            wx.hideLoading();
        });
    },

    chooseKeyword(e) {
        const key = e.currentTarget.dataset.key;
        this.setData({
            story: this.data.story + "（寻得：" + key + "）",
            keywords: []
        });
    },
  
    startAdventure() {
        wx.showLoading({ title: "故事启封..." });
        return this.callDeepSeek({
            model: "deepseek-chat",
            messages: [{
                role: "user",
                content: `请生成一个冒险故事开头，200字左右，并提供3个接下来的选择。
                    格式要求：
                    - 故事内容多行
                    - 每个选项独占一行，格式为“选项一：xxx”，“选项二：xxx”，“选项三：xxx”`
            }]
        }).then(res => {
            if (res.choices && res.choices.length > 0) {
                this.processAdventureResponse(res.choices[0].message.content || "");
            } else {
                wx.showToast({ title: "没有返回内容", icon: "none" });
            }
        }).catch(err => {
            console.error(err);
            wx.showToast({ title: "生成失败", icon: "none" });
        }).finally(() => {
            wx.hideLoading();
        });
    },
  
    chooseOption(e) {
        const choice = e.currentTarget.dataset.choice;
        if (!choice) return;
        wx.showLoading({ title: "深入奇境..." });
        
        // 保存用户的选择
        const updatedStory = this.data.story + "\n\n" + "你选择了：" + choice;
        this.setData({ story: updatedStory });
        
        return this.callDeepSeek({
            model: "deepseek-chat",
            messages: [{
                role: "user",
                content: `当前故事：
                    ${updatedStory}
  
                    请继续写故事，并提供3个后续选项，每个选项独占一行，格式“选项一：xxx”“选项二：xxx”“选项三：xxx”`
            }]
        }).then(res => {
            if (res.choices && res.choices.length > 0) {
                this.processAdventureResponse(res.choices[0].message.content || "");
                
                // 在故事更新后立即保存到仓库
                this.saveStoryToRepository();
            } else {
                wx.showToast({ title: "没有返回内容", icon: "none" });
            }
        }).catch(err => {
            console.error(err);
            wx.showToast({ title: "生成失败", icon: "none" });
        }).finally(() => {
            wx.hideLoading();
        });
    },
  
    processAdventureResponse(text) {
        const lines = text.split("\n").map(l => l.trim()).filter(l => l.length > 0);
        let newStoryLines = [];
        let options = [];
  
        lines.forEach(line => {
            line = line.replace(/^[^\u4e00-\u9fa5]*/, ""); // 去掉行首非中文字符
            if (/^选项[一二三四五六七八九十]/.test(line)) {
                options.push(line.replace(/^选项[一二三四五六七八九十][:：]/, "").trim());
            } else {
                newStoryLines.push(line);
            }
        });
      
        // 在原有故事内容的基础上追加新内容
        const updatedStory = this.data.story + "\n\n" + newStoryLines.join("\n");
        
        this.setData({
            story: updatedStory,
            options: options
        });
    },
  
    callDeepSeek(payload) {
        return new Promise((resolve, reject) => {
            wx.request({
                url: 'https://api.deepseek.com/v1/chat/completions',
                method: 'POST',
                header: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer sk-672dc07a3a704ac084b6340f205c4296' 
                },
                data: payload,
                success(res) { resolve(res.data); },
                fail(err) { reject(err); }
            });
        });
    }
});